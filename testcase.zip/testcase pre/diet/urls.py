from django.urls import path
from . import views


urlpatterns = [
    path('',views.home_view, name='home'),
    path('login/', views.auth_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('goal/', views.goal_view, name='goal'),
    path('login/profile/', views.profile_view, name='profile'),
    path('login/dash/', views.dash_view, name='dash'),
    path('form/', views.form_view, name='form'),
    
]