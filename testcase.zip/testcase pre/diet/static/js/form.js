document.addEventListener("DOMContentLoaded", function () 
{
    const formSteps = document.querySelectorAll(".form-step");
    const nextBtns = document.querySelectorAll(".next");
    const prevBtns = document.querySelectorAll(".prev");
    const progressBar = document.getElementById("progress-bar");
    let currentStep = 0;
    let options = document.querySelectorAll(".option");

    function showStep(step) {
        formSteps.forEach((stepDiv, index) => {
            stepDiv.classList.toggle("active", index === step);
        });
        progressBar.style.width = ((step + 1) / formSteps.length) * 100 + "%";
    }

    nextBtns.forEach((btn) => {
        btn.addEventListener("click", function () {
            if (validateStep(currentStep)) {
                currentStep++;
                if (currentStep < formSteps.length) {
                    showStep(currentStep);
                }
            }
        });
    });

    prevBtns.forEach((btn) => {
        btn.addEventListener("click", function () {
            currentStep--;
            showStep(currentStep);
        });
    });

    function validateStep(step) {
        let inputs = formSteps[step].querySelectorAll("input, select");
        for (let input of inputs) {
            if (!input.value.trim()) {
                alert("Please fill in all required fields.");
                return false;
            }
        }
        return true;
    }

    document.getElementById("multiStepForm").addEventListener("submit", function (event) {
        event.preventDefault();
        alert("Form submitted successfully!");
    });

    showStep(currentStep);

    options.forEach(option => {
        option.addEventListener("click", function() {
            this.classList.toggle("selected"); // Toggle selection
        });
    });
   
});