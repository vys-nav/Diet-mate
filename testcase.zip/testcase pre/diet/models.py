from django.db import models
from django.contrib.auth.models import User

class UserGoal(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    goal = models.CharField(max_length=50)
    weight_goal = models.FloatField()
    target_fat = models.FloatField()
    age = models.IntegerField()
    gender = models.CharField(max_length=10)
    diet_preference = models.CharField(max_length=20, blank=True, null=True)
    foods_to_avoid = models.TextField(blank=True, null=True)
    vitamin_deficiencies = models.TextField(blank=True, null=True)
    height = models.FloatField()
    weight = models.FloatField()
    fat_percentage = models.FloatField()
    activity_level = models.CharField(max_length=20, blank=True, null=True)
    blood_glucose = models.FloatField()
    blood_pressure = models.FloatField()
    cholesterol = models.FloatField()
    streak = models.IntegerField(default=0)
    last_login_date = models.DateField(blank=True, null=True)
    bmr = models.FloatField(blank=True, null=True)
    calorie_goal = models.FloatField(blank=True, null=True)
    protein = models.FloatField(blank=True, null=True)
    carbs = models.FloatField(blank=True, null=True)
    fats = models.FloatField(blank=True, null=True)
    recomended_diet = models.TextField(blank=True, null=True)
    

    def __str__(self):
        return f"{self.user.username}'s Goal"
    

class Nutrition(models.Model):
    food = models.CharField(max_length=255)
    category = models.CharField(max_length=100)
    calories = models.FloatField()
    protein = models.FloatField()
    carbohydrates = models.FloatField()
    fats = models.FloatField()
    fiber = models.FloatField()
    sugar = models.FloatField()
    vitamins = models.TextField()
    minerals = models.TextField()

    def __str__(self):
        return self.food