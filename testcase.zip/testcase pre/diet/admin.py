from django.contrib import admin
from .models import UserGoal,Nutrition

@admin.register(UserGoal)
class UserGoalAdmin(admin.ModelAdmin):
    list_display = ('user', 'goal', 'weight_goal', 'target_fat', 'age', 'gender', 'diet_preference', 'foods_to_avoid', 'vitamin_deficiencies', 'height', 'weight', 'fat_percentage', 'activity_level', 'blood_glucose', 'blood_pressure', 'cholesterol')





@admin.register(Nutrition)
class NutritionAdmin(admin.ModelAdmin):
    list_display = ('food', 'category', 'calories', 'protein', 'carbohydrates', 'fats', 'fiber', 'sugar', 'vitamins', 'minerals')