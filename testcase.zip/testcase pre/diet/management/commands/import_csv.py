import csv
from django.core.management.base import BaseCommand
from diet.models import Nutrition

class Command(BaseCommand):
    help = 'Import food nutrition data from a CSV file'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str, help='Path to the CSV file')

    def handle(self, *args, **kwargs):
        csv_file = kwargs['csv_file']
        with open(csv_file, newline='', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                Nutrition.objects.create(
                    food=row['Food'],
                    category=row['Category'],
                    calories=row['Calories'],
                    protein=row['Protein'],
                    carbohydrates=row['Carbohydrates'],
                    fats=row['Fats'],
                    fiber=row['Fiber'],
                    sugar=row['Sugar'],
                    vitamins=row['Vitamins'],
                    minerals=row['Minerals']
                )
        self.stdout.write(self.style.SUCCESS('Data imported successfully!'))