from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import UserGoal, Nutrition
from datetime import date
import random


def auth_view(request):
    if request.method == "POST":
        if 'signup' in request.POST:  # Handle Signup
            name = request.POST.get("name")
            email = request.POST.get("email")
            password = request.POST.get("password")

            if User.objects.filter(username=email).exists():
                messages.error(request, "Email already registered")
            else:
                user = User.objects.create_user(username=email, password=password, first_name=name,email=email)
                user.save()
                login(request, user)  # Automatically log in the user after signup
                messages.success(request, "Account created successfully! Please log in.")
                return redirect("goal")

        elif 'login' in request.POST:  # Handle Login
            email = request.POST.get("email")
            password = request.POST.get("password")
            user = authenticate(request, username=email, password=password)

            if user:
                login(request, user)
                user_goal = UserGoal.objects.get(user=user)
                if user_goal.last_login_date != date.today():
                    user_goal.streak += 1
                    user_goal.last_login_date = date.today()
                    user_goal.save()
                return redirect("dash/")  # Redirect after login
            else:
                messages.error(request, "Invalid email or password")

    return render(request, "login.html")

def logout_view(request):
    logout(request)
    return redirect("/")

def home_view(request):
    return render(request, "home.html")


@login_required
def goal_view(request):
    if request.method == 'POST':
        # Extract data from the form
        goal = request.POST.get('goal')
        weight_goal = request.POST.get('kg')
        target_fat = request.POST.get('week_kg')
        age = request.POST.get('age')
        gender = request.POST.get('gender')
        diet_preference = request.POST.get('preference')
        foods_to_avoid = ','.join(request.POST.getlist('foods_to_avoid'))
        vitamin_deficiencies = ','.join(request.POST.getlist('vitamin_deficiencies'))
        height = request.POST.get('height')
        weight = request.POST.get('weight')
        fat_percentage = request.POST.get('week_fat')
        activity_level = request.POST.get('activity')
        blood_glucose = request.POST.get('glucose')
        blood_pressure = request.POST.get('bp')
        cholesterol = request.POST.get('cholesterol')

        # Save the data to the database
        UserGoal.objects.update_or_create(
            user=request.user,
            defaults={
                'goal': goal,
                'weight_goal': weight_goal,
                'target_fat': target_fat,
                'age': age,
                'gender': gender,
                'diet_preference': diet_preference,
                'foods_to_avoid': foods_to_avoid,
                'vitamin_deficiencies': vitamin_deficiencies,
                'height': height,
                'weight': weight,
                'fat_percentage': fat_percentage,
                'activity_level': activity_level,
                'blood_glucose': blood_glucose,
                'blood_pressure': blood_pressure,
                'cholesterol': cholesterol,
            }
        )
        logout(request)  # Log out the user after saving the goal
        return redirect('/login/')  # Redirect to a dashboard or success page

    return render(request, 'goal.html')


@login_required
def profile_view(request): 
    user = UserGoal.objects.get(user=request.user)
    return render(request, 'profile.html', {'user': user})


@login_required
def dash_view(request):
    user = UserGoal.objects.get(user=request.user)
    if user.gender.lower() == 'male':
        bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age + 5
    else:
        bmr = 10 * user.weight + 6.25 * user.height - 5 * user.age - 161

    # Step 3: Adjust for activity level
    activity_factors = {
        'Sedentary': 1.2,
        'Moderate': 1.55,
        'Active': 1.9
    }
    adjusted_bmr = bmr * activity_factors[user.activity_level]

    # Step 4: Determine caloric goal
    if user.goal.lower() == 'lose fat':
        caloric_goal = adjusted_bmr - 500
    elif user.goal.lower() == 'build muscle':
        caloric_goal = adjusted_bmr + 500
    else:
        caloric_goal = adjusted_bmr

    # Step 5: Macronutrient distribution
    macronutrient_ratios = {
        'lose fat': {'protein': 0.3, 'carbs': 0.4, 'fats': 0.3},
        'build muscle': {'protein': 0.25, 'carbs': 0.5, 'fats': 0.25},
        'maintain weight': {'protein': 0.2, 'carbs': 0.5, 'fats': 0.3}
    }
    ratios = macronutrient_ratios[user.goal.lower()]
    protein_grams = (caloric_goal * ratios['protein']) / 4
    carbs_grams = (caloric_goal * ratios['carbs']) / 4
    fats_grams = (caloric_goal * ratios['fats']) / 9
    user.bmr = bmr
    user.calorie_goal = caloric_goal
    user.protein = protein_grams
    user.carbs = carbs_grams
    user.fats = fats_grams
    user.save()
    foods = Nutrition.objects.all()

    # Generate diet plan using the algorithm
    diet_plan = suggest_diet_plan_logic(user, foods)

    return render(request, 'dash.html', {'user': user, 'diet_plan': diet_plan})



@login_required
def form_view(request):
    if request.method == 'POST':
        # Extract data from the form
        height = request.POST.get('height')
        weight = request.POST.get('weight')
        fat_percentage = request.POST.get('week_fat')
        activity_level = request.POST.get('activity')
        blood_glucose = request.POST.get('glucose')
        blood_pressure = request.POST.get('bp')
        cholesterol = request.POST.get('cholesterol')

        # Update the UserGoal model for the logged-in user
        user_goal, created = UserGoal.objects.update_or_create(
            user=request.user,
            defaults={
                'height': height,
                'weight': weight,
                'fat_percentage': fat_percentage,
                'activity_level': activity_level,
                'blood_glucose': blood_glucose,
                'blood_pressure': blood_pressure,
                'cholesterol': cholesterol,
            }
        )
        logout(request)

        # Redirect to a success page or dashboard
        return redirect('/login/')  # Replace 'dash' with your desired redirect URL

    return render(request, 'form.html')  # Render the form template if GET request


def suggest_diet_plan_logic(user, foods):
    """
    Suggest a diet plan based on user's health conditions, diet preferences, and nutritional needs.
    """
    # Initialize diet plan
    diet_plan = {
        'Breakfast': [],
        'Lunch': [],
        'Dinner': [],
        'Snacks': []
    }

    # Macronutrient distribution for each meal
    meal_ratios = {
        'Breakfast': 0.25,  # 25% of daily calories
        'Lunch': 0.35,      # 35% of daily calories
        'Dinner': 0.30,     # 30% of daily calories
        'Snacks': 0.10      # 10% of daily calories
    }

    # Filter foods based on diet preferences
    if user.diet_preference.lower() == 'vegan':
        foods = foods.filter(category__in=['Fruit','Vegetable','Grain','Nuts'])
    elif user.diet_preference.lower() == 'veg':
        foods = foods.filter(category__in=['Fruit','Vegetable','Grain','Nuts','Diary'])
    else:
        foods = foods

    # Further filter foods based on health conditions
    if user.cholesterol > 200:  # High cholesterol
        foods = foods.filter(fats__lte=10)  # Low-fat foods
    if user.blood_glucose > 140:  # Diabetes
        foods = foods.filter(carbs__lte=30)  # Low-carb foods
    if user.blood_pressure > 130:  # High blood pressure
        foods = foods.filter(minerals__lte=140)  # Low-sodium foods


    foods = list(foods)
    random.shuffle(foods)

    # Track used foods to avoid repetition
    used_foods = set()

    # Suggest food items for each meal
    for meal, ratio in meal_ratios.items():
        meal_calories = user.calorie_goal * ratio
        meal_protein = user.protein * ratio
        meal_carbs = user.carbs * ratio
        meal_fats = user.fats * ratio

        # Select foods for the meal
        selected_foods = []
        current_calories = 0
        current_protein = 0
        current_carbs = 0
        current_fats = 0

        # Ensure each meal has a variety of food categories
        for category in ['Protein', 'Carbs', 'Fats']:
            category_foods = [food for food in foods if food.id not in used_foods]
            random.shuffle(category_foods)  # Shuffle foods in this category for randomness

            for food in category_foods:
                if (current_calories + food.calories <= meal_calories and
                        current_protein + food.protein <= meal_protein and
                        current_carbs + food.carbohydrates <= meal_carbs and
                        current_fats + food.fats <= meal_fats):
                    selected_foods.append(food)
                    used_foods.add(food.id)
                    current_calories += food.calories
                    current_protein += food.protein
                    current_carbs += food.carbohydrates
                    current_fats += food.fats

                    # Stop adding foods if the meal's calorie limit is reached
                    if current_calories >= meal_calories:
                        break

        diet_plan[meal] = selected_foods
    print(diet_plan)

    return diet_plan